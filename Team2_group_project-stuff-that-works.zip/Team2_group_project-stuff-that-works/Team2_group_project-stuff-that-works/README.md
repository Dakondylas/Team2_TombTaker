---TOMB TAKER---
By Dillon Idris, and Yunus
Tomb Taker is a game that tests your knowledge in this year's Python and Networking curriculum
Your goal is to reach the bottom of the tomb and clain the fabled three peices of Reeses
Get seven of the ten puzzles correct to win the game
SETUP
Download the game folder, extract the file bonzo tomb and inside bonzo tomb unzip voicelines, and run main(1).py
Ensure variables.txt is downloaded and in the folder
In pycharm open up the terminal (you will find it at the bottom left of the screen) once there type "pip install wheel" press enter then type "pip install pygame"
CONTROLS
Use keys 1,2,3,4 to answer multiple choice question
Use your keyboard to complete fill in the blank questions
4/15/2024
Team2_group_project